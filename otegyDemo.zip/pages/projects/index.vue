<template>
  <div>
    <h1>پروژه ها</h1>
    <hr>

    <div class="row">
      <div class="col-md-6">
        <nuxt-link to="/projects/lee1">
          لیوان
        </nuxt-link>
      </div>
    </div>

  </div>
</template>

<script>
export default {}
</script>
