<template>
  <div>
    <h1>پنل کاربری</h1>
    <hr>
    <b-card>
      <b-card-text>
        از این قسمت میتوانید محصول اضافه کنید
      </b-card-text>
      <b-link href="/products/add" class="card-link ml-4">اضافه کردن محصول</b-link>

    </b-card>
    <b-card
      title="پنل بازاریابی و ثبت کسب و کارها"
      class="mt-2"
    >
      <b-card-text>
        از این قسمت میتوانید لیست کسب و کارها را مشاهده و بروز رسانی کنید
      </b-card-text>
      <b-link href="/businesses/add" class="card-link ml-4">اضافه کردن کسب و کار</b-link>
      <b-link href="/businesses" class="card-link">لیست کسب و کارها</b-link>
    </b-card>
  </div>
</template>

<script>
export default {
}
</script>
