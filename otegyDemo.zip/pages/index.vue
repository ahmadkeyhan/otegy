<template>
  <div dir="rtl">
    <h1>welcome to otegy</h1>
  </div>
</template>

<script>
export default {}
</script>
