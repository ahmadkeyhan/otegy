<template>
  <div>
    <h1>خدمات</h1>
  </div>
</template>

<script>
export default {}
</script>
