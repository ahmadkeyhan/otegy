<template>
  <b-container dir="rtl">
    <headernav :navtitle="'studio.'"></headernav>
  </b-container>
</template>

<script>
export default {}
</script>
