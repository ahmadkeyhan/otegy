<template>
  <b-container dir="rtl">
    <headernav :navtitle="'story.'"></headernav>
  </b-container>
</template>

<script>
export default {}
</script>
