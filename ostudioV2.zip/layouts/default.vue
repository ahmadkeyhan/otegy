<template>
  <div>
    <Nuxt />
  </div>
</template>

<style>
html, body {
  font-family: 'Markazi Text', serif;
  font-size: 16px;
  word-spacing: 1px;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
  background-color: #212121;
}

*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
}

</style>
